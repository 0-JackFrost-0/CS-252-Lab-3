The code is a primitive prototype of what we intend to implement.
It only carries basic features that give an idea of the feasibility. 

To replicate a half-duplex transmission, do the following:

0) Ensure you have the dependencies: pyAudio, libportaudio, sounddevice, numpy and scipy

1) run the file using "python3 SwarComm_BETA.py" command. 

2) On a device with a microphone, run the above command and type "RECEIVE" and hit enter.
   This device is now an active receptor

3) On a device with a speaker, run the above command and type "TRANSMIT" and hit enter

4) Enter the bitstring to be transmitted and hit enter

5) Watch the padded notes get received at the other end!

6) After the receiver times out after a long silence, the code received will be displayed.

This is a very primitive prototype and the actual SwarComm is much more interesting :) 